import React from 'react';

const Header: React.FC = () => {
  return (
    <header className="bg-white/80 backdrop-blur-md shadow-sm sticky top-0 z-50">
      <div className="container mx-auto px-6 py-4 flex justify-between items-center">
        <a href="#" className="text-2xl font-bold">
          <span className="bg-gradient-to-r from-orange-500 to-amber-400 text-transparent bg-clip-text">
            Soniya Trip Adventure
          </span>
        </a>
        <nav className="hidden md:flex space-x-8">
          <a href="#packages" className="text-gray-600 hover:text-orange-500 transition-colors duration-300">Paket Trip</a>
          <a href="#testimonials" className="text-gray-600 hover:text-orange-500 transition-colors duration-300">Testimoni</a>
          <a href="#booking" className="text-gray-600 hover:text-orange-500 transition-colors duration-300">Pesan Sekarang</a>
          <a href="#contact" className="text-gray-600 hover:text-orange-500 transition-colors duration-300">Kontak</a>
        </nav>
      </div>
    </header>
  );
};

export default Header;