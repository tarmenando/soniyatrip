
export interface TravelPackage {
  id: string;
  name: string;
  description: string;
  imageUrl: string;
}
